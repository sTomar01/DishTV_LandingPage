<?php
if(isset($_REQUEST['submit'])) 
{
// EDIT THE 2 LINES BELOW AS REQUIRED
$email_to = "Getnewdthoffer@gmail.com";
$email_subject = "Call Back Request for Dish TV";
// validation expected data exists
if(!isset($_POST['phone']))
{
die('We are sorry, but there appears to be a problem with the form you submitted.');      
}
$phone=$_POST['phone']; //required
function clean_string($string) 
{
$bad = array("content-type","bcc:","to:","cc:","href");
return str_replace($bad,"",$string);
}
@$email_message .= "Phone: ".clean_string($phone)."\n";
// create email headers
$headers = "Getnewdthoffer@gmail.com\r\n";
//'Reply-To: '.$email_from."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject,$email_message, $headers); 
}
?>
<html>
  <head>
    <style>
      .centerIt{
        display:flex;
        height:100vh;
        flex-direction:column;
        justify-content:center;
        align-items:center;
      }
    </style>
      <!-- Event snippet for Page view conversion page
      In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
      <script>
      function gtag_report_conversion(url) {
        var callback = function () {
          if (typeof(url) != 'undefined') {
            window.location = url;
          }
        };
        gtag('event', 'conversion', {
            'send_to': 'AW-442015755/XgHyCOSLgPQBEIvA4tIB',
            'event_callback': callback
        });
        return false;
      }
    </script>

    <!-- Event snippet for Page view conversion page
    In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
    <!-- Global site tag (gtag.js) - Google Ads: 442015755 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-442015755"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());

      gtag('config', 'AW-442015755');
    </script>

    <!-- Event snippet for Page view dish tv conversion page -->
    <script>
      gtag('event', 'conversion', {'send_to': 'AW-442015755/HbCDCNuZ6PQBEIvA4tIB'});
    </script>

</head>
<body>
<div class="centerIt" align="center">
  <h1 style="text-align: center;"><span style="color: #333399;">Thank You for Sharing your Information</span></h1>
  <h2 style="text-align: center;"><span style="color: #333399;">We will contact you shortly</span></h2>
</div>
<meta http-equiv="refresh" content="3; url=./index2.html" />
</body>
</html>