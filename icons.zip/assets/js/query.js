var hidden = true;
var queryForm = document.getElementById("queryFormContainer");

function enquiryForm() {
    console.log("working");
    if (hidden) {
        queryForm.style.position = "fixed";
        queryForm.style.display = "flex";
        queryForm.style.transition = "all .5s ease";
        queryForm.style.transform = "translateX(0%) translateY(0%)";
        queryForm.style.visibility = "visible";
        queryForm.style.zIndex = "7";
        hidden = false;
    } else {
        queryForm.style.transition = "all .5s ease";
        queryForm.style.visibility = "hidden";
        queryForm.style.transform = "translateY(300%)";

        hidden = true;
    }
}