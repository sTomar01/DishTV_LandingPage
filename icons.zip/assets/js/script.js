!function(e){"use strict";var a=e("body");e('a.nav-item[href*="#"]:not([href="#"])').on("click",function(){if(location.pathname.replace(/^\//,"")===this.pathname.replace(/^\//,"")&&location.hostname===this.hostname){var a=e(this.hash),t=!!this.hash.slice(1)&&e("[name="+this.hash.slice(1)+"]");if((a=a.length?a:t).length)return e("html, body").animate({scrollTop:a.offset().top-70},1e3,"easeInOutExpo"),!1}}),e(".nav-item").on("click",function(){e(".navbar-collapse").collapse("hide")});var t=e(".dropdown");t.length>0&&(t.on("mouseover",function(){e(".dropdown-menu",this).not(".in .dropdown-menu").stop(!0,!0).fadeIn("400"),e(this).addClass("open")}),t.on("mouseleave",function(){e(".dropdown-menu",this).not(".in .dropdown-menu").stop(!0,!0).fadeOut("400"),e(this).removeClass("open")})),a.scrollspy({target:"#navigation",offset:90});var i=e(".video-play");i.length>0&&i.magnificPopup({type:"iframe",removalDelay:160,preloader:!0,

fixedContentPos:!1,callbacks:{beforeOpen:function(){this.st.image.markup=this.st.image.markup.replace("mfp-figure","mfp-figure mfp-with-anim"),this.st.mainClass=this.st.el.attr("data-effect")}}});

var l=e(".has-carousel");l.length>0&&l.each(function(){var a=e(this),t=a.data("items")?a.data("items"):4,i=t>=3?3:t,l=i>=2?2:i,n=a.data("delay")?a.data("delay"):6e3,
s=!!a.data("auto"),
r=!!a.data("loop"),
o=!!a.data("dots"),
d=!!a.data("navs"),
h=!!a.data("center"),
m=a.data("margin")?a.data("margin"):30,
c=a.data("animateOut")?a.data("animateOut"):"fadeOut";
a.owlCarousel({navText:["<i class='fa fa-angle-left'></i>",
"<i class='fa fa-angle-right'></i>"],
items:t,loop:r,nav:d,dots:o,margin:m,
center:h,animateOut:c,autoplay:s,autoplayTimeout:n,autoplaySpeed:300,
responsive:{0:{items:1},480:{items:l},
768:{items:i},
1170:{items:t}}})})
;var n=e(".imagebg");
n.length>0&&n.each(function(){var a=e(this),
t=a.parent(),i=a.data("overlay"),
l=a.children("img").attr("src"),
n=void 0!==i&&""!==i&&i.split("-");
void 0!==l&&""!==l&&(t.hasClass("has-bg-image")||t.addClass("has-bg-image"),
""!==n&&"dark"===n[0]&&(t.hasClass("light")||t.addClass("light")),
a.css("background-image",'url("'+l+'")').addClass("bg-image-loaded"))});
var s=e("#contact-form");if(s.length>0){if(!e().validate||!e().ajaxSubmit)return console.log("quoteForm: jQuery Form or Form Validate not Defined."),
!0;if(s.length>0){var r=s.find("select.required"),
o=s.find(".form-results");s.validate({invalidHandler:function(){o.slideUp(400)},
submitHandler:function(a){o.slideUp(400)
,e(a).ajaxSubmit({target:o,dataType:"json",
success:function(t){var i="error"===t.result?"alert-danger":"alert-success";o.removeClass("alert-danger alert-success").addClass("alert "+i).html(t.message).slideDown(400),
"error"!==t.result&&e(a).clearForm()}})}}),
r.on("change",function(){e(this).valid()})}}var d=e("#preloader");
d.length>0&&e(window).on("load",
function(){d.children().fadeOut(300),
d.delay(150).fadeOut(500),
e("body").delay(100).css({overflow:"visible"})}),
(new WOW).init(),e("#particles-js").length>0&&particlesJS("particles-js",
{particles:{number:{value:80,
density:{enable:!0,value_area:800}},
color:{value:"#ffffff"},
shape:{type:"circle",
stroke:{width:0,color:"#000000"},
polygon:{nb_sides:3},
image:{src:"img/github.svg",
width:100,height:100}},
opacity:{value:.5,
random:!1,anim:{enable:!1,speed:1,
opacity_min:.1,sync:!1}},
size:{value:3,random:!0,
anim:{enable:!1,speed:40,
size_min:.1,sync:!1}},
line_linked:{enable:!0,
distance:150,color:"#ffffff",
opacity:.4,width:1.3},
move:{enable:!0,speed:6,
direction:"none",random:!1,straight:!1,
out_mode:"out",
bounce:!1,attract:{enable:!1,
rotateX:600,rotateY:1200}}},
interactivity:{detect_on:"canvas",
events:{onhover:{enable:!0,mode:"repulse"},
onclick:{enable:!0,mode:"push"},
resize:!0},modes:{grab:{distance:400,
line_linked:{opacity:1}},
bubble:{distance:400,size:40,duration:2,opacity:1,speed:3},repulse:{distance:400,duration:.4},
push:{particles_nb:4},remove:{particles_nb:2}}},retina_detect:!0}),a.append('')}(jQuery);




